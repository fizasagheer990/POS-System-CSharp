﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace POS2
{
    public partial class Logins : Form
    {
        public Logins()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void Logins_Load(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 menu = new Form1();
            menu.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string connStr = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                string query = "SELECT * FROM Users WHERE Username=@u AND Password=@p";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@u", textBox1.Text);
                cmd.Parameters.AddWithValue("@p", textBox2.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password!", "Error");
                }
            }
        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            string connStr = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                string query = "SELECT * FROM Users WHERE Username=@u AND Password=@p";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@u", textBox1.Text);
                cmd.Parameters.AddWithValue("@p", textBox2.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password!", "Error");
                }
            }
        }
    }
}