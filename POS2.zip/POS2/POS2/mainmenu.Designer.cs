﻿namespace POS2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label2 = new Label();
            panel2 = new Panel();
            label14 = new Label();
            label9 = new Label();
            label4 = new Label();
            label8 = new Label();
            label5 = new Label();
            label7 = new Label();
            label6 = new Label();
            label1 = new Label();
            panel3 = new Panel();
            label3 = new Label();
            panel4 = new Panel();
            textBox1 = new TextBox();
            label10 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 64);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(481, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(781, 31);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(224, 224, 224);
            label2.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(310, 0);
            label2.Name = "label2";
            label2.Size = new Size(319, 29);
            label2.TabIndex = 3;
            label2.Text = "E-Commerce POS System";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Yellow;
            panel2.Controls.Add(label14);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Location = new Point(481, 38);
            panel2.Name = "panel2";
            panel2.Size = new Size(781, 40);
            panel2.TabIndex = 1;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(585, 8);
            label14.Name = "label14";
            label14.RightToLeft = RightToLeft.Yes;
            label14.Size = new Size(64, 25);
            label14.TabIndex = 4;
            label14.Text = "Billing ";
            label14.Click += label10_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(532, 8);
            label9.Name = "label9";
            label9.RightToLeft = RightToLeft.Yes;
            label9.Size = new Size(47, 25);
            label9.TabIndex = 4;
            label9.Text = "view";
            label9.Click += label9_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 8);
            label4.Name = "label4";
            label4.Size = new Size(74, 25);
            label4.TabIndex = 4;
            label4.Text = "Product";
            label4.Click += label4_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(430, 8);
            label8.Name = "label8";
            label8.Size = new Size(86, 25);
            label8.TabIndex = 4;
            label8.Text = "customer";
            label8.Click += label8_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(92, 8);
            label5.Name = "label5";
            label5.Size = new Size(116, 25);
            label5.TabIndex = 4;
            label5.Text = "Product View";
            label5.Click += label5_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(310, 8);
            label7.Name = "label7";
            label7.Size = new Size(114, 25);
            label7.TabIndex = 4;
            label7.Text = "SupplierView";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(223, 8);
            label6.Name = "label6";
            label6.Size = new Size(77, 25);
            label6.TabIndex = 4;
            label6.Text = "Supplier";
            label6.Click += label6_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(94, 21);
            label1.Name = "label1";
            label1.Size = new Size(164, 29);
            label1.TabIndex = 2;
            label1.Text = "Clothing Hub";
            label1.Click += label1_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Yellow;
            panel3.Controls.Add(label3);
            panel3.ForeColor = Color.FromArgb(0, 192, 0);
            panel3.Location = new Point(423, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(208, 25);
            panel3.TabIndex = 3;
            panel3.Paint += panel3_Paint;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(118, 25);
            label3.TabIndex = 4;
            label3.Text = "Clothing Hub";
            label3.Click += label3_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Cornsilk;
            panel4.Controls.Add(textBox1);
            panel4.Controls.Add(label10);
            panel4.Location = new Point(122, 113);
            panel4.Name = "panel4";
            panel4.Size = new Size(275, 181);
            panel4.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(3, 66);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(269, 93);
            textBox1.TabIndex = 3;
            textBox1.Text = "Supplier: New Fabrics  \r\nProvides: Ladies Dresses  \r\nLocation: Karachi";
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(16, 21);
            label10.Name = "label10";
            label10.Size = new Size(133, 29);
            label10.TabIndex = 2;
            label10.Text = "Supplier 1";
            label10.Click += label1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(20, 66);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(260, 93);
            textBox2.TabIndex = 3;
            textBox2.Text = "Supplier: Style Hub  \r\nProvides: Casual Dresses  \r\nLocation: Islamabad";
            textBox2.TextAlign = HorizontalAlignment.Center;
            textBox2.TextChanged += textBox1_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(13, 66);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(260, 93);
            textBox3.TabIndex = 3;
            textBox3.Text = "Supplier: Al-Hina Collection  \r\nProvides: Bridal Wear  \r\nLocation: Lahore";
            textBox3.TextAlign = HorizontalAlignment.Center;
            textBox3.TextChanged += textBox1_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(13, 70);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(260, 93);
            textBox4.TabIndex = 3;
            textBox4.Text = "Supplier: Fashion Point  \r\nProvides: Kids Wear  \r\nLocation: Multan";
            textBox4.TextAlign = HorizontalAlignment.Center;
            textBox4.TextChanged += textBox1_TextChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(9, 10);
            label11.Name = "label11";
            label11.Size = new Size(133, 29);
            label11.TabIndex = 2;
            label11.Text = "Supplier 3";
            label11.Click += label1_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(13, 10);
            label12.Name = "label12";
            label12.Size = new Size(133, 29);
            label12.TabIndex = 2;
            label12.Text = "Supplier 2";
            label12.Click += label1_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(13, 20);
            label13.Name = "label13";
            label13.Size = new Size(133, 29);
            label13.TabIndex = 2;
            label13.Text = "Supplier 4";
            label13.Click += label1_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Cornsilk;
            panel5.Controls.Add(label12);
            panel5.Controls.Add(textBox3);
            panel5.Location = new Point(452, 113);
            panel5.Name = "panel5";
            panel5.Size = new Size(288, 181);
            panel5.TabIndex = 4;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Cornsilk;
            panel6.Controls.Add(label11);
            panel6.Controls.Add(textBox2);
            panel6.Location = new Point(791, 113);
            panel6.Name = "panel6";
            panel6.Size = new Size(295, 181);
            panel6.TabIndex = 4;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Cornsilk;
            panel7.Controls.Add(label13);
            panel7.Controls.Add(textBox4);
            panel7.Location = new Point(452, 313);
            panel7.Name = "panel7";
            panel7.Size = new Size(288, 181);
            panel7.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1261, 516);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(label1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            ForeColor = SystemColors.ActiveCaptionText;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = " nmjfgvbvc  j";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Label label2;
        private Panel panel3;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Panel panel4;
        private Label label10;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label11;
        private Label label12;
        private Label label13;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Label label14;
    }
}
