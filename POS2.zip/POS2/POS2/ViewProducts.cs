﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace POS2
{
    public partial class ViewProducts : Form
    {
        string connStr = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";

        public ViewProducts()
        {
            InitializeComponent();
        }

        private void ViewProducts_Load(object sender, EventArgs e)
        {
            LoadData();
            comboBox1.Items.Add("Ladies Dresses");
            comboBox1.Items.Add("Bridal Wear");
            comboBox1.Items.Add("Casual Dresses");
            comboBox1.Items.Add("Kids Wear");
        }

        private void LoadData()
        {
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Products", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox2.Text = row.Cells[1].Value.ToString();
                comboBox1.Text = row.Cells[2].Value.ToString();
                textBox3.Text = row.Cells[3].Value.ToString();
                textBox1.Text = row.Cells[4].Value.ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox2.Text = row.Cells[1].Value.ToString();
                comboBox1.Text = row.Cells[2].Value.ToString();
                textBox3.Text = row.Cells[3].Value.ToString();
                textBox1.Text = row.Cells[4].Value.ToString();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                string query = "UPDATE Products SET ProductCategory=@cat, ProductPrice=@price, ProductQuantity=@qty WHERE ProductName=@name";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", textBox2.Text);
                cmd.Parameters.AddWithValue("@cat", comboBox1.Text);
                cmd.Parameters.AddWithValue("@price", textBox3.Text);
                cmd.Parameters.AddWithValue("@qty", textBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Updated!", "Success");
                LoadData();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                string query = "DELETE FROM Products WHERE ProductName=@name";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", textBox2.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Deleted!", "Success");
                LoadData();
                textBox2.Clear();
                comboBox1.SelectedIndex = -1;
                textBox3.Clear();
                textBox1.Clear();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            textBox2.Clear();
            comboBox1.SelectedIndex = -1;
            textBox3.Clear();
            textBox1.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 menu = new Form1();
            menu.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, System.Windows.Forms.PaintEventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void ViewProducts_Load_1(object sender, EventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { this.Close(); }
        private void button1_Click(object sender, EventArgs e) { }
        private void button2_Click(object sender, EventArgs e) { }
        private void button3_Click(object sender, EventArgs e) { }
    }
}