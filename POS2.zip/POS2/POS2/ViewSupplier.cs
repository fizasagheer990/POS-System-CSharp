﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace POS2
{
    public partial class ViewSupplier : Form
    {
        string connectionString = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";
        int selectedSupplierID = 0;

        public ViewSupplier()
        {
            InitializeComponent();
            LoadSuppliers();
        }

        private void ViewSupplier_Load(object sender, EventArgs e)
        {
            LoadSuppliers();
        }

        private void LoadSuppliers()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT * FROM Suppliers";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                selectedSupplierID = Convert.ToInt32(row.Cells["SupplierID"].Value);
                textBox1.Text = row.Cells["SupplierName"].Value.ToString();
                textBox2.Text = row.Cells["Address"].Value.ToString();
                textBox3.Text = row.Cells["Phone"].Value.ToString();
                textBox4.Text = row.Cells["Remarks"].Value.ToString();
            }
        }

        // EDIT BUTTON
        private void button1_Click(object sender, EventArgs e)
        {
            if (selectedSupplierID == 0)
            {
                MessageBox.Show("Please select a supplier first!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"UPDATE Suppliers SET 
                                    SupplierName = @Name,
                                    Address = @Address,
                                    Phone = @Phone,
                                    Remarks = @Remarks
                                    WHERE SupplierID = @ID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@Address", textBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", textBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@Remarks", textBox4.Text.Trim());
                    cmd.Parameters.AddWithValue("@ID", selectedSupplierID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Supplier updated successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSuppliers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // DELETE BUTTON
        private void button2_Click(object sender, EventArgs e)
        {
            if (selectedSupplierID == 0)
            {
                MessageBox.Show("Please select a supplier first!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure you want to delete?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        string query = "DELETE FROM Suppliers WHERE SupplierID = @ID";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@ID", selectedSupplierID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Supplier deleted successfully!", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        selectedSupplierID = 0;
                        LoadSuppliers();
                        ClearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // BACK BUTTON
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 Obj = new Form1();
            Obj.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 Obj = new Form1();
            Obj.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void ClearFields()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}