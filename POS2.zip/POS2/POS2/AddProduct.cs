﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace POS2
{
    public partial class AddProduct : Form
    {
        public AddProduct()
        {
            InitializeComponent();
        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Ladies Dresses");
            comboBox1.Items.Add("Bridal Wear");
            comboBox1.Items.Add("Casual Dresses");
            comboBox1.Items.Add("Kids Wear");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();
                string query = "INSERT INTO Products VALUES (@name, @cat, @price, @qty)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@cat", comboBox1.Text);
                cmd.Parameters.AddWithValue("@price", textBox4.Text);
                cmd.Parameters.AddWithValue("@qty", textBox3.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Saved!", "Success");
                button2_Click(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            comboBox1.SelectedIndex = -1;
            textBox4.Clear();
            textBox3.Clear();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { this.Close(); }
    }
}