﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace POS2
{
    public partial class Billing : Form
    {
        string connectionString = "Server=localhost\\SQLEXPRESS;Database=POSDb;Integrated Security=True;";
        decimal totalAmount = 0;

        public Billing()
        {
            InitializeComponent();
            LoadCustomers();
            LoadProducts();
            SetupCartGrid();
        }

        private void Billing_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null)
            {
                MessageBox.Show("Please select a customer!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView2.Rows.Count == 0)
            {
                MessageBox.Show("Please add products to cart!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlTransaction transaction = con.BeginTransaction();
                    try
                    {
                        string orderQuery = @"INSERT INTO Orders (CustomerID, TotalAmount, PaymentMethod, Status) 
                                            VALUES (@CustomerID, @Total, 'Cash', 'Completed');
                                            SELECT SCOPE_IDENTITY();";
                        SqlCommand orderCmd = new SqlCommand(orderQuery, con, transaction);
                        orderCmd.Parameters.AddWithValue("@CustomerID", comboBox1.SelectedValue);
                        orderCmd.Parameters.AddWithValue("@Total", totalAmount);
                        int orderID = Convert.ToInt32(orderCmd.ExecuteScalar());

                        foreach (DataGridViewRow row in dataGridView2.Rows)
                        {
                            if (row.Cells["ProductID"].Value != null)
                            {
                                string detailQuery = @"INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price, SubTotal) 
                                                      VALUES (@OrderID, @ProductID, @Qty, @Price, @SubTotal)";
                                SqlCommand detailCmd = new SqlCommand(detailQuery, con, transaction);
                                detailCmd.Parameters.AddWithValue("@OrderID", orderID);
                                detailCmd.Parameters.AddWithValue("@ProductID", row.Cells["ProductID"].Value);
                                detailCmd.Parameters.AddWithValue("@Qty", row.Cells["Quantity"].Value);
                                detailCmd.Parameters.AddWithValue("@Price", row.Cells["Price"].Value);
                                detailCmd.Parameters.AddWithValue("@SubTotal", row.Cells["SubTotal"].Value);
                                detailCmd.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();

                        string invoice = "CLOTHING HUB\n";
                        invoice += "E-Commerce POS System\n";
                        invoice += "Karachi, Pakistan\n";
                        invoice += "________________________________\n\n";
                        invoice += "Order ID  : #" + orderID + "\n";
                        invoice += "Customer  : " + comboBox1.Text + "\n";
                        invoice += "Date      : " + DateTime.Now.ToString("dd MMM yyyy") + "\n";
                        invoice += "Time      : " + DateTime.Now.ToString("hh:mm tt") + "\n";
                        invoice += "________________________________\n\n";
                        invoice += "ITEMS PURCHASED:\n\n";

                        foreach (DataGridViewRow row in dataGridView2.Rows)
                        {
                            if (row.Cells["ProductID"].Value != null)
                            {
                                invoice += "* " + row.Cells["ProductName"].Value.ToString() + "\n";
                                invoice += "  Qty      : " + row.Cells["Quantity"].Value.ToString() + "\n";
                                invoice += "  Price    : Rs." + row.Cells["Price"].Value.ToString() + "\n";
                                invoice += "  SubTotal : Rs." + row.Cells["SubTotal"].Value.ToString() + "\n\n";
                            }
                        }

                        invoice += "________________________________\n";
                        invoice += "TOTAL AMOUNT : Rs. " + totalAmount.ToString("0.00") + "\n";
                        invoice += "Payment Mode : Cash\n";
                        invoice += "________________________________\n\n";
                        invoice += "Thank you for shopping!\n";
                        invoice += "Please visit again!\n";

                        MessageBox.Show(invoice, "Invoice - Clothing Hub",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        dataGridView2.Rows.Clear();
                        totalAmount = 0;
                        label2.Text = "Total: Rs. 0.00";
                    }
                    catch
                    {
                        transaction.Rollback();
                        MessageBox.Show("Order save failed!", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 Obj = new Form1();
            Obj.Show();
            this.Hide();
        }

        private void LoadCustomers()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT CustomerID, CustomerName FROM Customers", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    comboBox1.DisplayMember = "CustomerName";
                    comboBox1.ValueMember = "CustomerID";
                    comboBox1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT ProductID, ProductName, ProductCategory, ProductPrice, ProductQuantity FROM Products", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoResizeColumns();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void SetupCartGrid()
        {
            dataGridView2.Columns.Clear();
            dataGridView2.Columns.Add("ProductID", "ProductID");
            dataGridView2.Columns.Add("ProductName", "Product Name");
            dataGridView2.Columns.Add("Price", "Price");
            dataGridView2.Columns.Add("Quantity", "Quantity");
            dataGridView2.Columns.Add("SubTotal", "SubTotal");
            dataGridView2.Columns["ProductID"].Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                if (row.Cells["ProductID"].Value == null) return;
                if (row.Cells["ProductID"].Value == DBNull.Value) return;
                if (row.Cells["ProductName"].Value == null) return;
                if (row.Cells["ProductName"].Value == DBNull.Value) return;
                if (row.Cells["ProductPrice"].Value == null) return;
                if (row.Cells["ProductPrice"].Value == DBNull.Value) return;

                string productID = row.Cells["ProductID"].Value.ToString();
                string productName = row.Cells["ProductName"].Value.ToString();
                decimal price = Convert.ToDecimal(row.Cells["ProductPrice"].Value);

                foreach (DataGridViewRow cartRow in dataGridView2.Rows)
                {
                    if (cartRow.Cells["ProductID"].Value != null &&
                        cartRow.Cells["ProductID"].Value.ToString() == productID)
                    {
                        int qty = Convert.ToInt32(cartRow.Cells["Quantity"].Value) + 1;
                        cartRow.Cells["Quantity"].Value = qty;
                        cartRow.Cells["SubTotal"].Value = qty * price;
                        CalculateTotal();
                        return;
                    }
                }

                dataGridView2.Rows.Add(productID, productName, price, 1, price);
                CalculateTotal();
            }
        }

        private void CalculateTotal()
        {
            totalAmount = 0;
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                if (row.Cells["SubTotal"].Value != null)
                    totalAmount += Convert.ToDecimal(row.Cells["SubTotal"].Value);
            }
            label2.Text = "Total: Rs. " + totalAmount.ToString("0.00");
        }
    }
}