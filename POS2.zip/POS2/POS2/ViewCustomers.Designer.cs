﻿namespace POS2
{
    partial class ViewCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label3 = new Label();
            panel2 = new Panel();
            label2 = new Label();
            panel3 = new Panel();
            label6 = new Label();
            label8 = new Label();
            label10 = new Label();
            label4 = new Label();
            label9 = new Label();
            label7 = new Label();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            label5 = new Label();
            textBox1 = new TextBox();
            label12 = new Label();
            label13 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 64, 0);
            panel1.Controls.Add(label3);
            panel1.Location = new Point(424, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(815, 49);
            panel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Gadugi", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Silver;
            label3.Location = new Point(307, 8);
            label3.Name = "label3";
            label3.Size = new Size(346, 34);
            label3.TabIndex = 3;
            label3.Text = "E-Commerce POS System";
            label3.Click += label1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Yellow;
            panel2.Controls.Add(label2);
            panel2.Location = new Point(356, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(200, 26);
            panel2.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(39, -3);
            label2.Name = "label2";
            label2.Size = new Size(129, 28);
            label2.TabIndex = 3;
            label2.Text = "Clothing Hub";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Yellow;
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(label10);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(label7);
            panel3.Location = new Point(512, 56);
            panel3.Name = "panel3";
            panel3.Size = new Size(727, 49);
            panel3.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(102, 11);
            label6.Name = "label6";
            label6.Size = new Size(154, 32);
            label6.TabIndex = 4;
            label6.Text = "Product View";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(262, 11);
            label8.Name = "label8";
            label8.Size = new Size(102, 32);
            label8.TabIndex = 4;
            label8.Text = "Supplier";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(370, 11);
            label10.Name = "label10";
            label10.Size = new Size(160, 32);
            label10.TabIndex = 4;
            label10.Text = "View Supplier";
            label10.Click += label10_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(3, 11);
            label4.Name = "label4";
            label4.Size = new Size(96, 32);
            label4.TabIndex = 4;
            label4.Text = "Product";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(536, 11);
            label9.Name = "label9";
            label9.Size = new Size(117, 32);
            label9.TabIndex = 4;
            label9.Text = "Customer";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(659, 11);
            label7.Name = "label7";
            label7.Size = new Size(65, 32);
            label7.TabIndex = 4;
            label7.Text = "View";
            label7.Click += label7_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(87, 56);
            label1.Name = "label1";
            label1.Size = new Size(190, 34);
            label1.TabIndex = 3;
            label1.Text = "Clothing Hub";
            label1.Click += label1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(52, 133);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(687, 489);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(822, 151);
            label5.Name = "label5";
            label5.Size = new Size(202, 32);
            label5.TabIndex = 5;
            label5.Text = "Customer Name";
            label5.Click += label5_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(826, 186);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(251, 31);
            textBox1.TabIndex = 6;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(826, 234);
            label12.Name = "label12";
            label12.Size = new Size(229, 32);
            label12.TabIndex = 5;
            label12.Text = "Customer Address";
            label12.Click += label5_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(826, 413);
            label13.Name = "label13";
            label13.Size = new Size(208, 32);
            label13.TabIndex = 5;
            label13.Text = "Customer Phone";
            label13.Click += label5_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(826, 269);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(251, 127);
            textBox3.TabIndex = 6;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(826, 448);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(251, 31);
            textBox4.TabIndex = 6;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(14, 0);
            label14.Name = "label14";
            label14.Size = new Size(59, 32);
            label14.TabIndex = 5;
            label14.Text = "Edit";
            label14.Click += button1_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(16, 0);
            label15.Name = "label15";
            label15.Size = new Size(88, 32);
            label15.TabIndex = 5;
            label15.Text = "Delete";
            label15.Click += button2_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(3, 0);
            label16.Name = "label16";
            label16.Size = new Size(70, 32);
            label16.TabIndex = 5;
            label16.Text = "Back";
            label16.Click += button3_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Silver;
            panel4.Controls.Add(label14);
            panel4.Location = new Point(868, 523);
            panel4.Name = "panel4";
            panel4.Size = new Size(90, 35);
            panel4.TabIndex = 8;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Silver;
            panel5.Controls.Add(label15);
            panel5.Location = new Point(1001, 523);
            panel5.Name = "panel5";
            panel5.Size = new Size(119, 35);
            panel5.TabIndex = 8;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Silver;
            panel6.Controls.Add(label16);
            panel6.Location = new Point(952, 576);
            panel6.Name = "panel6";
            panel6.Size = new Size(90, 35);
            panel6.TabIndex = 8;
            // 
            // ViewCustomers
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1239, 681);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox1);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label5);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ViewCustomers";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ViewCustomers";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private DataGridView dataGridView1;
        private Label label5;
        private TextBox textBox1;
        private Label label12;
        private Label label13;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label14;
        private Label label15;
        private Label label16;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
    }
}